create definer = root@localhost view carsavailable as
select `car_dealership`.`carslisted`.`Build Year` AS `Build Year`,
       `car_dealership`.`carslisted`.`Kms`        AS `Kms`,
       `car_dealership`.`carslisted`.`DKK`        AS `DKK`,
       `car_dealership`.`carslisted`.`available`  AS `available`,
       `car_dealership`.`carslisted`.`colour`     AS `colour`,
       `car_dealership`.`carslisted`.`Make`       AS `Make`,
       `car_dealership`.`carslisted`.`Model`      AS `Model`,
       `car_dealership`.`carslisted`.`Seller`     AS `Seller`
from `car_dealership`.`carslisted`
where (`car_dealership`.`carslisted`.`available` = 1);

