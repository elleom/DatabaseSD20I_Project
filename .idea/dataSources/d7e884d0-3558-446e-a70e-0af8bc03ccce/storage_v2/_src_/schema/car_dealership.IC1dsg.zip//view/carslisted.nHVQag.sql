create view carslisted as
select `car_dealership`.`vehicle`.`year`      AS `Build Year`,
       `car_dealership`.`vehicle`.`Kms`       AS `Kms`,
       `car_dealership`.`vehicle`.`value`     AS `DKK`,
       `car_dealership`.`vehicle`.`available` AS `available`,
       `car_dealership`.`vehicle`.`colour`    AS `colour`,
       `m2`.`name`                            AS `Make`,
       `m`.`name`                             AS `Model`,
       `u`.`user_name`                        AS `Seller`
from ((((`car_dealership`.`vehicle` join `car_dealership`.`location` `l` on ((`l`.`ID` = `car_dealership`.`vehicle`.`locationID`))) join `car_dealership`.`model` `m` on ((`m`.`ID` = `car_dealership`.`vehicle`.`model_ID`))) join `car_dealership`.`users` `u` on ((`u`.`ID` = `car_dealership`.`vehicle`.`userID`)))
         join `car_dealership`.`make` `m2` on ((`m2`.`ID` = `m`.`makeID`)));

