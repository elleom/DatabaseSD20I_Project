create definer = root@localhost trigger makeUnavailable
    after insert
    on orders
    for each row
    update vehicle
        set available = false
       where vehicle.ID = (select vehicle_ID from orders where LAST_INSERT_ID(orders.ID));

