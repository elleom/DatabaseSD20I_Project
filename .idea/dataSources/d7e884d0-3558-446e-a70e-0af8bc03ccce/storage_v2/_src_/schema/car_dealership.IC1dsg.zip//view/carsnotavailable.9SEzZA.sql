create definer = root@localhost view carsnotavailable as
select `carslisted`.`Build Year` AS `Build Year`,
       `carslisted`.`Kms`        AS `Kms`,
       `carslisted`.`DKK`        AS `DKK`,
       `carslisted`.`available`  AS `available`,
       `carslisted`.`colour`     AS `colour`,
       `carslisted`.`Make`       AS `Make`,
       `carslisted`.`Model`      AS `Model`,
       `carslisted`.`Seller`     AS `Seller`
from `car_dealership`.`carslisted`
where (`carslisted`.`available` = 1);

