create definer = root@localhost trigger delUser
    after delete
    on users
    for each row
    insert into audit(type, date, user, detail)
            values ('delete', now(), session_user() , OLD.user_name);

