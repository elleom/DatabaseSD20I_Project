create definer = root@localhost trigger newUser
    after insert
    on users
    for each row
    insert into audit(type, date, user, detail)
            values ('registration', now(), session_user() , NEW.user_name);

