create
    definer = root@localhost procedure makeAvailable(IN in_id int)
BEGIN
    UPDATE vehicle
   set available = true
       where vehicle.ID = in_id;
END;

