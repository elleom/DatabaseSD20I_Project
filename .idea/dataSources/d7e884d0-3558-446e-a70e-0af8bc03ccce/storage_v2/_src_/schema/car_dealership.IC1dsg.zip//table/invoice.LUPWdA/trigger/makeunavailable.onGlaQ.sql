create definer = root@localhost trigger makeUnavailable
    after insert
    on invoice
    for each row
    update vehicle
        set orderID = (select ID from orders where orders.ID = (select max(orders.ID) from orders)),
            available = false
       where vehicle.ID = (select vehicle_ID from orders where LAST_INSERT_ID(orders.ID));

