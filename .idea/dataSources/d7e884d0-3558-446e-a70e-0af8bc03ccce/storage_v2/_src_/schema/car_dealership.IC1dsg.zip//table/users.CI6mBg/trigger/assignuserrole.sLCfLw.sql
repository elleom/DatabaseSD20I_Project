create definer = root@localhost trigger assignUserRole
    after insert
    on users
    for each row
    insert into users_roles(users_ID, roles_id)
        values (NEW.ID, 1);

