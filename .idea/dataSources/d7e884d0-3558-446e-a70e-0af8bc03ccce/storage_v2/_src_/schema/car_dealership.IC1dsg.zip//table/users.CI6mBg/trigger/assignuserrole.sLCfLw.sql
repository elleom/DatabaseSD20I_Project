create definer = root@localhost trigger assignUserRole
    after insert
    on users
    for each row
    insert into users_roles(roles_id, users_id)
        values (1, (select id from users where LAST_INSERT_ID(users.ID)));

